# AI KIDS - Quiz Interactivo

## 📁 Estructura de Archivos

```
ai-kids-quiz/
├── quiz-completo.html     # Archivo principal con todo el código
├── styles.css            # Estilos CSS separados (opcional)
├── quiz.js              # JavaScript separado (opcional)
├── logo.png             # Tu logo (reemplaza el placeholder)
└── README-DESCARGA.md   # Este archivo
```

## 🚀 Instrucciones de Uso

### Opción 1: Archivo Todo-en-Uno (Más Fácil)
1. Descarga el archivo `quiz-completo.html`
2. Abre el archivo en cualquier navegador web
3. ¡El quiz está listo para usar!

### Opción 2: Archivos Separados (Más Organizado)
1. Crea una carpeta llamada `ai-kids-quiz`
2. Coloca todos los archivos en la carpeta
3. Abre `quiz-completo.html` en el navegador

## 📝 Personalización

### Agregar tu Logo
1. Guarda tu logo como `logo.png` en la misma carpeta
2. En el archivo HTML, busca la línea con `logoPlaceholder`
3. Cambia la URL de la imagen por `"logo.png"`

### Cambiar las Preguntas
1. Abre el archivo `quiz.js` (o la sección `<script>` en el HTML)
2. Busca la variable `quizQuestions`
3. Reemplaza las preguntas con el contenido de tu Módulo 1

Formato de pregunta:
```javascript
{
    id: 1,
    question: "Tu pregunta aquí",
    options: [
        "Opción A",
        "Opción B", 
        "Opción C",
        "Opción D"
    ],
    correctAnswer: 0, // Índice de la respuesta correcta (0 = A, 1 = B, etc.)
    explanation: "Explicación de por qué esta es la respuesta correcta"
}
```

### Cambiar Colores
En el archivo CSS, modifica las variables:
```css
:root {
    --primary: #416bd7;     /* Azul principal */
    --accent: #ffff20;      /* Amarillo de destacados */
    --success: #22c55e;     /* Verde para respuestas correctas */
    --error: #ef4444;       /* Rojo para respuestas incorrectas */
}
```

## 📱 Características

- ✅ **Responsive**: Funciona en móvil, tablet y desktop
- ✅ **Interactivo**: Evaluación inmediata con ✓ y ✗
- ✅ **Barra de progreso**: Muestra el avance visual
- ✅ **Resultados detallados**: Con explicaciones educativas
- ✅ **Navegación**: Por teclado y botones
- ✅ **Reinicio**: Posibilidad de repetir el quiz

## 🌐 Navegadores Compatibles

- Chrome (recomendado)
- Firefox
- Safari
- Edge
- Cualquier navegador moderno

## 📧 Soporte

Para personalizar las preguntas con el contenido de tu Módulo 1, simplemente proporciona el texto y yo te ayudo a crear las preguntas específicas.

## 🎯 Próximos Pasos

1. **Reemplaza las preguntas** con tu contenido del Módulo 1
2. **Agrega tu logo** real
3. **Prueba en diferentes dispositivos**
4. **Comparte con tus estudiantes**

¡Tu quiz interactivo de AI Kids está listo! 🎉