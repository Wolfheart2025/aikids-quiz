import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import aiKidsLogo from '@/assets/ai-kids-logo.png';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

// Sample questions - replace with content from Module 1
const sampleQuestions: Question[] = [
  {
    id: 1,
    question: "¿Qué significa 'IA' o 'AI'?",
    options: [
      "Inteligencia Artificial",
      "Internet Avanzado", 
      "Información Automática",
      "Inventos Asombrosos"
    ],
    correctAnswer: 0,
    explanation: "IA significa Inteligencia Artificial, que es la capacidad de las máquinas para pensar y aprender como los humanos."
  },
  {
    id: 2,
    question: "¿Cuál de estos es un ejemplo de Inteligencia Artificial que usas todos los días?",
    options: [
      "Una bicicleta",
      "Un asistente de voz como Siri o Alexa",
      "Un lápiz",
      "Una pelota"
    ],
    correctAnswer: 1,
    explanation: "Los asistentes de voz como Siri o Alexa usan IA para entender lo que dices y responder de manera inteligente."
  },
  {
    id: 3,
    question: "¿Qué pueden hacer las computadoras con Inteligencia Artificial?",
    options: [
      "Solo jugar videojuegos",
      "Aprender y mejorar con el tiempo",
      "Solo mostrar imágenes",
      "Nada especial"
    ],
    correctAnswer: 1,
    explanation: "Una característica importante de la IA es que puede aprender de experiencias pasadas y mejorar su rendimiento con el tiempo."
  },
  {
    id: 4,
    question: "¿En qué se parece la IA al cerebro humano?",
    options: [
      "Ambos pueden procesar información",
      "Ambos son del mismo color",
      "Ambos pesan lo mismo",
      "No se parecen en nada"
    ],
    correctAnswer: 0,
    explanation: "Tanto la IA como el cerebro humano pueden procesar información, aunque de maneras diferentes."
  },
  {
    id: 5,
    question: "¿Por qué es importante aprender sobre Inteligencia Artificial?",
    options: [
      "Para volverse robot",
      "Porque está en todas partes y será parte de nuestro futuro",
      "Para asustar a los amigos",
      "No es importante"
    ],
    correctAnswer: 1,
    explanation: "Es importante aprender sobre IA porque está presente en muchas tecnologías que usamos y será aún más importante en el futuro."
  }
];

export const Quiz: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setQuizCompleted(true);
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setQuizCompleted(false);
  };

  const getScore = () => {
    return selectedAnswers.reduce((score, answer, index) => {
      return score + (answer === sampleQuestions[index].correctAnswer ? 1 : 0);
    }, 0);
  };

  const isAnswerCorrect = (questionIndex: number, answerIndex: number) => {
    return answerIndex === sampleQuestions[questionIndex].correctAnswer;
  };

  if (showResults) {
    const score = getScore();
    const percentage = Math.round((score / sampleQuestions.length) * 100);
    
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-primary text-primary-foreground p-4 md:p-6">
          <div className="flex items-center max-w-4xl mx-auto">
            <img 
              src={aiKidsLogo} 
              alt="AI Kids Academy" 
              className="h-12 md:h-16 w-auto mr-4"
            />
            <div>
              <h1 className="text-xl md:text-3xl font-bold">AI KIDS ACADEMY</h1>
              <p className="text-sm md:text-lg opacity-90">Resultados del Quiz - Módulo 1</p>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto p-4 md:p-6">
          <Card className="border-2">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl md:text-3xl">
                ¡Quiz Completado! 🎉
              </CardTitle>
              <div className="text-4xl md:text-6xl font-bold mt-4">
                <span className={score >= 4 ? "text-success" : score >= 3 ? "text-accent" : "text-error"}>
                  {score}/{sampleQuestions.length}
                </span>
              </div>
              <p className="text-lg md:text-xl mt-2">
                {percentage}% Correcto
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {sampleQuestions.map((question, qIndex) => {
                const userAnswer = selectedAnswers[qIndex];
                const isCorrect = isAnswerCorrect(qIndex, userAnswer);
                
                return (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex items-start gap-3 mb-3">
                      {isCorrect ? (
                        <CheckCircle className="h-6 w-6 text-success flex-shrink-0 mt-1" />
                      ) : (
                        <XCircle className="h-6 w-6 text-error flex-shrink-0 mt-1" />
                      )}
                      <div className="flex-1">
                        <h3 className="font-semibold text-sm md:text-base mb-2">
                          {qIndex + 1}. {question.question}
                        </h3>
                        <div className="text-sm space-y-1">
                          <p>
                            <span className="font-medium">Tu respuesta:</span>{" "}
                            <span className={isCorrect ? "text-success" : "text-error"}>
                              {question.options[userAnswer]}
                            </span>
                          </p>
                          {!isCorrect && (
                            <p>
                              <span className="font-medium">Respuesta correcta:</span>{" "}
                              <span className="text-success">
                                {question.options[question.correctAnswer]}
                              </span>
                            </p>
                          )}
                          {question.explanation && (
                            <p className="text-muted-foreground bg-muted p-2 rounded mt-2">
                              💡 {question.explanation}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              
              <div className="text-center pt-4">
                <Button 
                  onClick={handleRestart}
                  size="lg"
                  className="bg-primary hover:bg-primary/90"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Intentar de Nuevo
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const question = sampleQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / sampleQuestions.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4 md:p-6">
        <div className="flex items-center max-w-4xl mx-auto">
          <img 
            src={aiKidsLogo} 
            alt="AI Kids Academy" 
            className="h-12 md:h-16 w-auto mr-4"
          />
          <div className="flex-1">
            <h1 className="text-xl md:text-3xl font-bold">AI KIDS ACADEMY</h1>
            <p className="text-sm md:text-lg opacity-90">Quiz Interactivo - Módulo 1</p>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="bg-secondary p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between text-sm mb-2">
            <span>Pregunta {currentQuestion + 1} de {sampleQuestions.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-3">
            <div 
              className="bg-accent h-3 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quiz Content */}
      <main className="max-w-4xl mx-auto p-4 md:p-6">
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-lg md:text-2xl">
              {question.question}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`w-full p-4 text-left border-2 rounded-lg transition-all hover:border-primary/50 ${
                  selectedAnswers[currentQuestion] === index
                    ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                    : 'border-border hover:bg-muted/50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswers[currentQuestion] === index
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-muted-foreground'
                  }`}>
                    <span className="text-sm font-bold">
                      {String.fromCharCode(65 + index)}
                    </span>
                  </div>
                  <span className="text-sm md:text-base">{option}</span>
                </div>
              </button>
            ))}
            
            <div className="flex justify-between pt-6">
              <Button 
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                variant="outline"
                size="lg"
              >
                Anterior
              </Button>
              
              <Button 
                onClick={handleNext}
                disabled={selectedAnswers[currentQuestion] === undefined}
                size="lg"
                className="bg-primary hover:bg-primary/90"
              >
                {currentQuestion === sampleQuestions.length - 1 ? 'Finalizar' : 'Siguiente'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};